#include "src/Adaptor2d/Adaptor2d_Curve2d.hxx"
