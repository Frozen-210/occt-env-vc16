#include "src/BinMDataStd/BinMDataStd_AsciiStringDriver.hxx"
