#include "src/AppDef/AppDef_BSpParFunctionOfMyBSplGradientOfBSplineCompute.hxx"
