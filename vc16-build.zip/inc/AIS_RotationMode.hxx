#include "src/AIS/AIS_RotationMode.hxx"
