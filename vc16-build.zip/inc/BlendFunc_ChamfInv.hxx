#include "src/BlendFunc/BlendFunc_ChamfInv.hxx"
