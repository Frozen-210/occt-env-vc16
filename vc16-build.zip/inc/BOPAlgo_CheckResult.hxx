#include "src/BOPAlgo/BOPAlgo_CheckResult.hxx"
