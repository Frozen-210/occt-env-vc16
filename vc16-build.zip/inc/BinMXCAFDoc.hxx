#include "src/BinMXCAFDoc/BinMXCAFDoc.hxx"
