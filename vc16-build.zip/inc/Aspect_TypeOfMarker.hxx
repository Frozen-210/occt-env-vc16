#include "src/Aspect/Aspect_TypeOfMarker.hxx"
