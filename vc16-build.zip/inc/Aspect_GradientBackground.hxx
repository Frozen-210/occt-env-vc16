#include "src/Aspect/Aspect_GradientBackground.hxx"
