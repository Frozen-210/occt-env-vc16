#include "src/BinTools/BinTools_LocationSetPtr.hxx"
