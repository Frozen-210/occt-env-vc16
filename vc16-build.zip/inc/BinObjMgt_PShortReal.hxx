#include "src/BinObjMgt/BinObjMgt_PShortReal.hxx"
