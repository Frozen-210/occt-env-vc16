#include "src/Blend/Blend_SequenceOfPoint.hxx"
