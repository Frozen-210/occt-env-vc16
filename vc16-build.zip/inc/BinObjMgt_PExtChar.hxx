#include "src/BinObjMgt/BinObjMgt_PExtChar.hxx"
