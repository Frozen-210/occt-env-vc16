#include "src/Bnd/Bnd_Array1OfBox2d.hxx"
