#include "src/BlendFunc/BlendFunc_CSConstRad.hxx"
