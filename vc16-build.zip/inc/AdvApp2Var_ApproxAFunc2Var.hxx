#include "src/AdvApp2Var/AdvApp2Var_ApproxAFunc2Var.hxx"
