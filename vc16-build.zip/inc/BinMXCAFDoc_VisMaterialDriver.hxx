#include "src/BinMXCAFDoc/BinMXCAFDoc_VisMaterialDriver.hxx"
