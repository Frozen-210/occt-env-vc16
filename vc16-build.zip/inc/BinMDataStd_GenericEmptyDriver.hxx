#include "src/BinMDataStd/BinMDataStd_GenericEmptyDriver.hxx"
