#include "src/AppParCurves/AppParCurves_HArray1OfMultiBSpCurve.hxx"
