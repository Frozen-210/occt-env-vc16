#include "src/AppParCurves/AppParCurves_MultiBSpCurve.hxx"
