#include "src/BlendFunc/BlendFunc_ConstThroatWithPenetration.hxx"
