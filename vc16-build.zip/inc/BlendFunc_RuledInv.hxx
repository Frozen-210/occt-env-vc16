#include "src/BlendFunc/BlendFunc_RuledInv.hxx"
