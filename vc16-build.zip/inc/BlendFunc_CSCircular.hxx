#include "src/BlendFunc/BlendFunc_CSCircular.hxx"
