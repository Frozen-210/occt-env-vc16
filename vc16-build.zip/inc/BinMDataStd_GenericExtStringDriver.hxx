#include "src/BinMDataStd/BinMDataStd_GenericExtStringDriver.hxx"
