#include "src/BinMXCAFDoc/BinMXCAFDoc_CentroidDriver.hxx"
