#include "src/BlendFunc/BlendFunc_Ruled.hxx"
