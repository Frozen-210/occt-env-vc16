#include "src/Aspect/Aspect_TypeOfHighlightMethod.hxx"
