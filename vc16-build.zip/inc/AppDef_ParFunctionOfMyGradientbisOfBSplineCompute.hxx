#include "src/AppDef/AppDef_ParFunctionOfMyGradientbisOfBSplineCompute.hxx"
