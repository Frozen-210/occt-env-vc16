#include "src/AppDef/AppDef_SmoothCriterion.hxx"
