#include "src/BlendFunc/BlendFunc_GenChamfer.hxx"
