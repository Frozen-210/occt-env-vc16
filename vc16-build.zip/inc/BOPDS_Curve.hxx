#include "src/BOPDS/BOPDS_Curve.hxx"
