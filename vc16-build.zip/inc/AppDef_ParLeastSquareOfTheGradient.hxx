#include "src/AppDef/AppDef_ParLeastSquareOfTheGradient.hxx"
