#include "src/Bisector/Bisector_FunctionInter.hxx"
