#include "src/AIS/AIS_AnimationAxisRotation.hxx"
