#include "src/AppDef/AppDef_ParFunctionOfTheGradient.hxx"
