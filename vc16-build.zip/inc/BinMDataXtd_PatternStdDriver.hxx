#include "src/BinMDataXtd/BinMDataXtd_PatternStdDriver.hxx"
