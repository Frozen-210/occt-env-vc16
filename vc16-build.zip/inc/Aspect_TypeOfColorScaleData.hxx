#include "src/Aspect/Aspect_TypeOfColorScaleData.hxx"
