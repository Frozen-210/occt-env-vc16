#include "src/Adaptor3d/Adaptor3d_Curve.hxx"
