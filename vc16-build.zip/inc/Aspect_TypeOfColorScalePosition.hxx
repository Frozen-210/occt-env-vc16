#include "src/Aspect/Aspect_TypeOfColorScalePosition.hxx"
