#include "src/BlendFunc/BlendFunc_Chamfer.hxx"
