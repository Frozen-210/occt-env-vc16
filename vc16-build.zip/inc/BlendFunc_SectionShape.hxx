#include "src/BlendFunc/BlendFunc_SectionShape.hxx"
