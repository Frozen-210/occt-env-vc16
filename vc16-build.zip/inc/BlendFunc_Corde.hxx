#include "src/BlendFunc/BlendFunc_Corde.hxx"
