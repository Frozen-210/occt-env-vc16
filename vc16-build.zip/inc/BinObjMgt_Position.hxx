#include "src/BinObjMgt/BinObjMgt_Position.hxx"
