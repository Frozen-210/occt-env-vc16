#include "src/BlendFunc/BlendFunc_ConstThroatWithPenetrationInv.hxx"
