#include "src/AppDef/AppDef_Gradient_BFGSOfMyGradientbisOfBSplineCompute.hxx"
