#include "src/Blend/Blend_FuncInv.hxx"
