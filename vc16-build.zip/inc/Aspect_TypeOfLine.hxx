#include "src/Aspect/Aspect_TypeOfLine.hxx"
