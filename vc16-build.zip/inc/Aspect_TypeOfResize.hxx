#include "src/Aspect/Aspect_TypeOfResize.hxx"
