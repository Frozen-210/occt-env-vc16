#include "src/Aspect/Aspect_GradientFillMethod.hxx"
