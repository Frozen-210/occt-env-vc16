#include "src/Aspect/Aspect_TypeOfTriedronPosition.hxx"
