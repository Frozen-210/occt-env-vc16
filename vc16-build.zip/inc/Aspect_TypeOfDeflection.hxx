#include "src/Aspect/Aspect_TypeOfDeflection.hxx"
