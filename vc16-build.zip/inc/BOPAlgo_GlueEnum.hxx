#include "src/BOPAlgo/BOPAlgo_GlueEnum.hxx"
