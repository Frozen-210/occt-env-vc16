#include "src/BOPAlgo/BOPAlgo_WireEdgeSet.hxx"
