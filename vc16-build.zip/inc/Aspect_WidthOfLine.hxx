#include "src/Aspect/Aspect_WidthOfLine.hxx"
