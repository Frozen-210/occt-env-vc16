#include "src/Aspect/Aspect_TypeOfColorScaleOrientation.hxx"
