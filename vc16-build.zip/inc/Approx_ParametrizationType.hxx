#include "src/Approx/Approx_ParametrizationType.hxx"
