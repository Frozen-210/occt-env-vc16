#include "src/Approx/Approx_SequenceOfHArray1OfReal.hxx"
