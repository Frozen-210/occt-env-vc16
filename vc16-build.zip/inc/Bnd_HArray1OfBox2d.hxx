#include "src/Bnd/Bnd_HArray1OfBox2d.hxx"
