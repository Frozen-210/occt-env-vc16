#include "src/Blend/Blend_CurvPointFuncInv.hxx"
