#include "src/Aspect/Aspect_SkydomeBackground.hxx"
