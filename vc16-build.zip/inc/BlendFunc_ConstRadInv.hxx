#include "src/BlendFunc/BlendFunc_ConstRadInv.hxx"
