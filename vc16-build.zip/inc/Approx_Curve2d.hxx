#include "src/Approx/Approx_Curve2d.hxx"
