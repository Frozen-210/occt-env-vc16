#include "src/Blend/Blend_AppFunction.hxx"
