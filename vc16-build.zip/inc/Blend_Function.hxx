#include "src/Blend/Blend_Function.hxx"
