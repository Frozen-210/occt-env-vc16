#include "src/BinMFunction/BinMFunction_ScopeDriver.hxx"
