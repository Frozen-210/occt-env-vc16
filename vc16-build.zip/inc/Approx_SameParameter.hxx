#include "src/Approx/Approx_SameParameter.hxx"
