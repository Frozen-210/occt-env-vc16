#include "src/BOPAlgo/BOPAlgo_CheckerSI.hxx"
