#include "src/AppDef/AppDef_ResConstraintOfTheGradient.hxx"
