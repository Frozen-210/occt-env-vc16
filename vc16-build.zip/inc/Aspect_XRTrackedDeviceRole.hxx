#include "src/Aspect/Aspect_XRTrackedDeviceRole.hxx"
