#include "src/Aspect/Aspect_TypeOfStyleText.hxx"
