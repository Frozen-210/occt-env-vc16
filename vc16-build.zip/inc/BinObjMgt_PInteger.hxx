#include "src/BinObjMgt/BinObjMgt_PInteger.hxx"
