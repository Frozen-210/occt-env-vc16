#include "src/Aspect/Aspect_SequenceOfColor.hxx"
