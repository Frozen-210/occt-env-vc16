#include "src/BiTgte/BiTgte_ContactType.hxx"
