#include "src/AppDef/AppDef_ParLeastSquareOfMyGradientOfCompute.hxx"
