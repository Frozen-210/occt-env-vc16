#include "src/BinMNaming/BinMNaming_NamedShapeDriver.hxx"
