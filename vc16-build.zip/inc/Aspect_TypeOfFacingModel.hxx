#include "src/Aspect/Aspect_TypeOfFacingModel.hxx"
