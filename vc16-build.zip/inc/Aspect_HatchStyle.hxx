#include "src/Aspect/Aspect_HatchStyle.hxx"
