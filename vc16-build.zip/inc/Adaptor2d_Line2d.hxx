#include "src/Adaptor2d/Adaptor2d_Line2d.hxx"
