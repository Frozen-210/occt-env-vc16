#include "src/BlendFunc/BlendFunc_Tensor.hxx"
