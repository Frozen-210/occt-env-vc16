#include "src/BlendFunc/BlendFunc_ConstThroat.hxx"
