#include "src/AppDef/AppDef_ResConstraintOfMyGradientbisOfBSplineCompute.hxx"
