#include "src/BlendFunc/BlendFunc_ConstThroatInv.hxx"
