#include "src/BOPAlgo/BOPAlgo_WireSplitter.hxx"
