#include "src/BinMNaming/BinMNaming.hxx"
