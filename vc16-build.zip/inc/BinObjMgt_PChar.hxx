#include "src/BinObjMgt/BinObjMgt_PChar.hxx"
