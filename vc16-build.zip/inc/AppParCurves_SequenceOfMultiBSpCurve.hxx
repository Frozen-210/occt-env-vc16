#include "src/AppParCurves/AppParCurves_SequenceOfMultiBSpCurve.hxx"
