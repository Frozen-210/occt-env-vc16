#include "src/BinObjMgt/BinObjMgt_Persistent.hxx"
