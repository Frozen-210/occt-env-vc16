#include "src/BinMXCAFDoc/BinMXCAFDoc_AssemblyItemRefDriver.hxx"
