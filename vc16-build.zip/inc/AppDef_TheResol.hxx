#include "src/AppDef/AppDef_TheResol.hxx"
