#include "src/BiTgte/BiTgte_CurveOnVertex.hxx"
