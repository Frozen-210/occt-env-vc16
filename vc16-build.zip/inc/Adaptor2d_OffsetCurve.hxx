#include "src/Adaptor2d/Adaptor2d_OffsetCurve.hxx"
