#include "src/BlendFunc/BlendFunc_ConstRad.hxx"
