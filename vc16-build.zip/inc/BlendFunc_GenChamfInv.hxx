#include "src/BlendFunc/BlendFunc_GenChamfInv.hxx"
