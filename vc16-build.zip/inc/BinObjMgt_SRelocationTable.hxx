#include "src/BinObjMgt/BinObjMgt_SRelocationTable.hxx"
