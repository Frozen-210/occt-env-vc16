#include "src/BinObjMgt/BinObjMgt_RRelocationTable.hxx"
